java -Dapple.laf.useScreenMenuBar=true -cp lib/epsgraphics.jar:lib/Jama-1.0.1.jar:lib/xerces.jar:lib/jaybird-full-3.0.9.jar:lib/SAOExplorer-3.6.1.jar:lib/exp4j-0.4.8.jar SAOExplorer.SAOExplorer
